package br.com.appcadastrorest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCadastroRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCadastroRestApplication.class, args);
	}

}
