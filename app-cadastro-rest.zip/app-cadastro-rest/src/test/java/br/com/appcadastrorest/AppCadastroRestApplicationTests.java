package br.com.appcadastrorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppCadastroRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
